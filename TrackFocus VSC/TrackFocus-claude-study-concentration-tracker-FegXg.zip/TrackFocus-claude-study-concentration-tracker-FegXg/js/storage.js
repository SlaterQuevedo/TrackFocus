// Capa de persistencia. Una sola clave raíz para facilitar export/import y futura migración.
const Storage = (() => {
  const KEY = 'trackfocus.v1';

  const DEFAULT_STATE = {
    schemaVersion: 1,
    currentEmail: null,
    students: {},
    subjectsByInstitution: {
      colegio: ['Matemática', 'Comunicación', 'Física', 'Química', 'Inglés', 'Historia']
    },
    customSubjects: {},
    sessions: []
  };

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return structuredClone(DEFAULT_STATE);
      const parsed = JSON.parse(raw);
      return { ...structuredClone(DEFAULT_STATE), ...parsed };
    } catch (e) {
      console.error('Storage corrupted, resetting:', e);
      return structuredClone(DEFAULT_STATE);
    }
  }

  function save(state) {
    localStorage.setItem(KEY, JSON.stringify(state));
  }

  let state = load();

  return {
    get: () => state,
    set: (mutator) => {
      mutator(state);
      save(state);
    },
    reset: () => {
      state = structuredClone(DEFAULT_STATE);
      save(state);
    },
    DEFAULT_STATE
  };
})();
