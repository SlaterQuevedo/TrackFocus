// CRUD de sesiones de estudio.
const Sessions = (() => {

  const PREVIOUS_ACTIVITIES = [
    { id: 'comer', label: 'Comer' },
    { id: 'dormir', label: 'Dormir' },
    { id: 'ejercicio', label: 'Ejercicio' },
    { id: 'cafe', label: 'Café' },
    { id: 'descanso', label: 'Descanso' },
    { id: 'otra', label: 'Otra' }
  ];

  const LIKERT = [
    { v: 1, label: 'Nada concentrado' },
    { v: 2, label: 'Poco concentrado' },
    { v: 3, label: 'Regular' },
    { v: 4, label: 'Bastante concentrado' },
    { v: 5, label: 'Totalmente concentrado' }
  ];

  function uuid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  function add(session) {
    const required = ['email', 'datetime', 'institutionType', 'subject', 'concentration', 'durationMin', 'previousActivity'];
    for (const k of required) {
      if (session[k] === undefined || session[k] === null || session[k] === '') {
        throw new Error(`Falta el campo: ${k}`);
      }
    }
    const record = {
      id: uuid(),
      email: session.email,
      datetime: session.datetime,
      institutionType: session.institutionType,
      subject: session.subject,
      concentration: Number(session.concentration),
      durationMin: Number(session.durationMin),
      previousActivity: session.previousActivity,
      previousActivityOther: session.previousActivityOther || '',
      comment: session.comment || ''
    };
    Storage.set(s => s.sessions.push(record));
    return record;
  }

  function remove(id) {
    Storage.set(s => { s.sessions = s.sessions.filter(x => x.id !== id); });
  }

  function listFor(email, filters = {}) {
    const s = Storage.get();
    let list = s.sessions.filter(x => x.email === email);
    if (filters.subject) list = list.filter(x => x.subject === filters.subject);
    if (filters.from) list = list.filter(x => x.datetime >= filters.from);
    if (filters.to) list = list.filter(x => x.datetime <= filters.to);
    return list.sort((a, b) => b.datetime.localeCompare(a.datetime));
  }

  return { PREVIOUS_ACTIVITIES, LIKERT, add, remove, listFor };
})();
