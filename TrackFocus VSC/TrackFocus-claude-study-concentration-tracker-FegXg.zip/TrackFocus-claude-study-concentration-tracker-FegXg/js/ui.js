// Render de pantallas. Cada función screen* devuelve HTML y luego "wires" engancha eventos.
const UI = (() => {

  const root = () => document.getElementById('app');
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));

  function flash(msg, type = 'success') {
    const el = document.createElement('div');
    el.className = `alert ${type}`;
    el.textContent = msg;
    root().prepend(el);
    setTimeout(() => el.remove(), 2800);
  }

  // ---- Pantalla 1: Bienvenida / identificación ----
  function screenWelcome() {
    return `
      <section class="welcome">
        <h1>TrackFocus</h1>
        <p>Mide tus patrones de concentración y descubre los mejores horarios, hábitos y métodos para estudiar.</p>
        <div class="card" style="max-width:440px;margin:0 auto;text-align:left;">
          <h2>Comencemos</h2>
          <form id="loginForm">
            <div class="field">
              <label>Nombre del estudiante</label>
              <input name="name" required placeholder="Ej. María López" />
            </div>
            <div class="field">
              <label>Gmail personal</label>
              <input name="email" type="email" required placeholder="estudiante@gmail.com" />
            </div>
            <button class="primary" type="submit">Continuar</button>
          </form>
        </div>
      </section>`;
  }

  function wireWelcome() {
    document.getElementById('loginForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const email = String(fd.get('email')).trim().toLowerCase();
      const name = String(fd.get('name')).trim();
      if (!email.endsWith('@gmail.com')) {
        flash('Por favor usa una cuenta de Gmail (@gmail.com).', 'error');
        return;
      }
      Storage.set(s => {
        if (!s.students[email]) {
          s.students[email] = { name, email, institutionType: null, createdAt: new Date().toISOString() };
        } else {
          s.students[email].name = name;
        }
        s.currentEmail = email;
      });
      App.go(Storage.get().students[email].institutionType ? 'dashboard' : 'institution');
    });
  }

  // ---- Pantalla 2: Selección de institución ----
  function screenInstitution() {
    const list = Subjects.listInstitutions();
    return `
      <h1>Selecciona tu tipo de institución</h1>
      <p class="muted">Las materias se cargarán automáticamente según tu elección.</p>
      <div class="choice-grid" style="margin-top:18px;">
        ${list.map(i => `
          <div class="choice ${i.enabled ? '' : 'disabled'}" data-id="${esc(i.id)}">
            <div class="ic">${i.icon}</div>
            <h2 style="margin:8px 0 4px;">${esc(i.label)}</h2>
            <p class="muted" style="margin:0;font-size:12px;">${i.enabled ? 'Disponible' : 'Próximamente'}</p>
          </div>`).join('')}
      </div>`;
  }

  function wireInstitution() {
    root().querySelectorAll('.choice').forEach(el => {
      if (el.classList.contains('disabled')) return;
      el.addEventListener('click', () => {
        const id = el.dataset.id;
        const email = Storage.get().currentEmail;
        Storage.set(s => { s.students[email].institutionType = id; });
        App.go('dashboard');
      });
    });
  }

  // ---- Pantalla 3: Dashboard ----
  function screenDashboard() {
    const s = Storage.get();
    const student = s.students[s.currentEmail];
    const inst = Subjects.getInstitution(student.institutionType);
    const sessions = Sessions.listFor(student.email);
    const sum = Stats.summary(sessions);
    return `
      <h1>Hola, ${esc(student.name)} 👋</h1>
      <p class="muted">Institución: <strong>${esc(inst?.label || '—')}</strong></p>

      <div class="grid cols-4" style="margin:16px 0 4px;">
        <div class="kpi"><div class="v">${sum.total}</div><div class="l">Sesiones</div></div>
        <div class="kpi"><div class="v">${sum.avgConc || '—'}</div><div class="l">Concentración prom.</div></div>
        <div class="kpi"><div class="v">${sum.totalMin}</div><div class="l">Minutos totales</div></div>
        <div class="kpi"><div class="v">${sum.avgDur || '—'}</div><div class="l">Min/sesión prom.</div></div>
      </div>

      <div class="grid cols-3" style="margin-top:18px;">
        <div class="card">
          <h2>📝 Registrar sesión</h2>
          <p class="muted">Anota tu última sesión de estudio rápidamente.</p>
          <button class="primary" data-go="new-session">Nueva sesión</button>
        </div>
        <div class="card">
          <h2>📚 Materias</h2>
          <p class="muted">Revisa o agrega cursos personalizados.</p>
          <button class="ghost" data-go="subjects">Gestionar</button>
        </div>
        <div class="card">
          <h2>📊 Estadísticas</h2>
          <p class="muted">Promedios por materia, horario y hábito.</p>
          <button class="ghost" data-go="stats">Ver estadísticas</button>
        </div>
        <div class="card">
          <h2>🗂️ Historial</h2>
          <p class="muted">Todas tus sesiones, filtrables y exportables.</p>
          <button class="ghost" data-go="history">Ver historial</button>
        </div>
        <div class="card">
          <h2>💡 Recomendaciones</h2>
          <p class="muted">Sugerencias de horarios y hábitos según tus datos.</p>
          <button class="ghost" data-go="recommend">Ver recomendaciones</button>
        </div>
        <div class="card">
          <h2>📤 Exportar</h2>
          <p class="muted">Descarga tus sesiones en CSV (Excel).</p>
          <button class="ghost" id="quickExport">Exportar CSV</button>
        </div>
      </div>`;
  }

  function wireDashboard() {
    root().querySelectorAll('[data-go]').forEach(b => b.addEventListener('click', () => App.go(b.dataset.go)));
    document.getElementById('quickExport').addEventListener('click', () => {
      const email = Storage.get().currentEmail;
      const sess = Sessions.listFor(email);
      if (!sess.length) return flash('No hay sesiones para exportar.', 'error');
      Exporter.exportSessions(sess);
    });
  }

  // ---- Pantalla 4: Registrar sesión ----
  function screenNewSession() {
    const s = Storage.get();
    const student = s.students[s.currentEmail];
    const subjects = Subjects.listSubjects(student.institutionType, student.email);
    const now = new Date();
    const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16);

    return `
      <h1>Registrar sesión de estudio</h1>
      <form id="sessionForm" class="card">
        <div class="row">
          <div class="field">
            <label>Fecha y hora</label>
            <input type="datetime-local" name="datetime" value="${local}" required />
          </div>
          <div class="field">
            <label>Duración (minutos)</label>
            <input type="number" name="durationMin" min="1" max="600" value="30" required />
          </div>
        </div>

        <div class="field">
          <label>Curso / materia</label>
          <select name="subject" required>
            ${subjects.map(x => `<option>${esc(x)}</option>`).join('')}
          </select>
        </div>

        <div class="field">
          <label>Nivel de concentración</label>
          <div class="likert">
            ${Sessions.LIKERT.map(l => `
              <label title="${esc(l.label)}">
                <input type="radio" name="concentration" value="${l.v}" ${l.v === 3 ? 'checked' : ''} required />
                <div class="lk-num">${l.v}</div>
                <div class="lk-txt">${esc(l.label)}</div>
              </label>`).join('')}
          </div>
        </div>

        <div class="row">
          <div class="field">
            <label>Actividad previa</label>
            <select name="previousActivity" id="prevAct" required>
              ${Sessions.PREVIOUS_ACTIVITIES.map(a => `<option value="${a.id}">${esc(a.label)}</option>`).join('')}
            </select>
          </div>
          <div class="field" id="otherWrap" style="display:none;">
            <label>Especificar otra</label>
            <input name="previousActivityOther" placeholder="Ej. ducharme" />
          </div>
        </div>

        <div class="field">
          <label>Comentario (opcional)</label>
          <textarea name="comment" placeholder="¿Qué notaste? ¿Distracciones, ambiente, energía?"></textarea>
        </div>

        <div style="display:flex;gap:10px;justify-content:flex-end;">
          <button type="button" class="ghost" data-go="dashboard">Cancelar</button>
          <button class="primary" type="submit">Guardar sesión</button>
        </div>
      </form>`;
  }

  function wireNewSession() {
    const form = document.getElementById('sessionForm');
    const prev = document.getElementById('prevAct');
    const other = document.getElementById('otherWrap');
    prev.addEventListener('change', () => other.style.display = prev.value === 'otra' ? '' : 'none');

    root().querySelectorAll('[data-go]').forEach(b => b.addEventListener('click', () => App.go(b.dataset.go)));

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const s = Storage.get();
      try {
        Sessions.add({
          email: s.currentEmail,
          datetime: new Date(fd.get('datetime')).toISOString(),
          institutionType: s.students[s.currentEmail].institutionType,
          subject: fd.get('subject'),
          concentration: fd.get('concentration'),
          durationMin: fd.get('durationMin'),
          previousActivity: fd.get('previousActivity'),
          previousActivityOther: fd.get('previousActivityOther') || '',
          comment: fd.get('comment') || ''
        });
        App.go('dashboard');
        flash('Sesión guardada correctamente.', 'success');
      } catch (err) {
        flash(err.message, 'error');
      }
    });
  }

  // ---- Pantalla 5: Materias ----
  function screenSubjects() {
    const s = Storage.get();
    const student = s.students[s.currentEmail];
    const base = s.subjectsByInstitution[student.institutionType] || [];
    const custom = (s.customSubjects[student.email] || []);

    return `
      <h1>Materias</h1>
      <p class="muted">Estas son las materias disponibles para tu institución. Puedes agregar cursos personalizados.</p>

      <div class="card">
        <h3>Materias predefinidas</h3>
        <div>${base.map(x => `<span class="chip">${esc(x)}</span>`).join('') || '<span class="muted">Ninguna</span>'}</div>
      </div>

      <div class="card">
        <h3>Cursos personalizados</h3>
        <div id="customList">${custom.map(x => `<span class="chip">${esc(x)}<span class="x" data-del="${esc(x)}" title="Quitar">✕</span></span>`).join('') || '<span class="muted">Aún no agregaste cursos.</span>'}</div>
        <form id="addSubjectForm" style="margin-top:14px;display:flex;gap:8px;">
          <input name="subject" placeholder="Ej. Robótica, Filosofía, Educación Física…" style="flex:1;background:var(--bg-2);color:var(--text);border:1px solid var(--border);border-radius:10px;padding:10px;" />
          <button class="primary" type="submit">Agregar curso personalizado</button>
        </form>
      </div>`;
  }

  function wireSubjects() {
    const email = Storage.get().currentEmail;
    document.getElementById('addSubjectForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const name = new FormData(e.target).get('subject');
      try {
        Subjects.addCustomSubject(email, name);
        App.go('subjects');
        flash('Curso agregado.', 'success');
      } catch (err) { flash(err.message, 'error'); }
    });
    root().querySelectorAll('[data-del]').forEach(el => {
      el.addEventListener('click', () => {
        Subjects.removeCustomSubject(email, el.dataset.del);
        App.go('subjects');
      });
    });
  }

  // ---- Pantalla 6: Historial ----
  function screenHistory(filters = {}) {
    const s = Storage.get();
    const email = s.currentEmail;
    const subjects = Subjects.listSubjects(s.students[email].institutionType, email);
    const list = Sessions.listFor(email, filters);

    return `
      <h1>Historial de sesiones</h1>
      <div class="toolbar">
        <div class="filters">
          <select id="fSubject">
            <option value="">Todas las materias</option>
            ${subjects.map(x => `<option ${filters.subject === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}
          </select>
          <input type="date" id="fFrom" value="${filters.fromDate || ''}" />
          <input type="date" id="fTo" value="${filters.toDate || ''}" />
          <button class="ghost" id="applyF">Aplicar</button>
          <button class="ghost" id="clearF">Limpiar</button>
        </div>
        <button class="primary" id="exportBtn">Exportar CSV</button>
      </div>

      <div class="card" style="padding:0;overflow:auto;">
        ${list.length === 0 ? '<div class="empty">No hay sesiones con esos filtros.</div>' : `
        <table class="table">
          <thead><tr>
            <th>Fecha</th><th>Materia</th><th>Conc.</th><th>Min</th><th>Actividad previa</th><th>Comentario</th><th></th>
          </tr></thead>
          <tbody>
            ${list.map(x => `
              <tr>
                <td>${new Date(x.datetime).toLocaleString('es-PE')}</td>
                <td>${esc(x.subject)}</td>
                <td><strong>${x.concentration}</strong>/5</td>
                <td>${x.durationMin}</td>
                <td>${esc(x.previousActivity)}${x.previousActivityOther ? ' — ' + esc(x.previousActivityOther) : ''}</td>
                <td>${esc(x.comment)}</td>
                <td><button class="danger" data-rm="${x.id}">Eliminar</button></td>
              </tr>`).join('')}
          </tbody>
        </table>`}
      </div>`;
  }

  function wireHistory() {
    const email = Storage.get().currentEmail;

    document.getElementById('applyF').addEventListener('click', () => {
      const subject = document.getElementById('fSubject').value;
      const fromDate = document.getElementById('fFrom').value;
      const toDate = document.getElementById('fTo').value;
      App._historyFilters = {
        subject,
        fromDate, toDate,
        from: fromDate ? new Date(fromDate).toISOString() : '',
        to: toDate ? new Date(toDate + 'T23:59:59').toISOString() : ''
      };
      App.go('history');
    });

    document.getElementById('clearF').addEventListener('click', () => {
      App._historyFilters = {};
      App.go('history');
    });

    document.getElementById('exportBtn').addEventListener('click', () => {
      const list = Sessions.listFor(email, App._historyFilters || {});
      if (!list.length) return flash('No hay sesiones para exportar.', 'error');
      Exporter.exportSessions(list);
    });

    root().querySelectorAll('[data-rm]').forEach(b => {
      b.addEventListener('click', () => {
        if (!confirm('¿Eliminar esta sesión?')) return;
        Sessions.remove(b.dataset.rm);
        App.go('history');
      });
    });
  }

  // ---- Pantalla 7: Estadísticas ----
  function screenStats() {
    const email = Storage.get().currentEmail;
    const sessions = Sessions.listFor(email);
    if (!sessions.length) {
      return `<h1>Estadísticas</h1><div class="card empty">Aún no tienes sesiones registradas. Empieza por <a href="#" data-go="new-session" style="color:var(--accent);">registrar tu primera sesión</a>.</div>`;
    }

    const sum = Stats.summary(sessions);
    const subs = Stats.bySubject(sessions);
    const buckets = Stats.byHourBucket(sessions);
    const acts = Stats.byPreviousActivity(sessions);
    const dist = Stats.likertDistribution(sessions);
    const total = sessions.length;

    const renderBar = (rows, key) => rows.map(r => {
      const pct = (r.avgConcentration / 5) * 100;
      return `
        <div>
          <div style="display:flex;justify-content:space-between;font-size:13px;">
            <span>${esc(r[key])}</span>
            <span class="muted">${r.avgConcentration}/5 · ${r.count} ses.</span>
          </div>
          <div class="bar"><span style="width:${pct}%"></span></div>
        </div>`;
    }).join('');

    return `
      <h1>Estadísticas</h1>
      <div class="grid cols-4">
        <div class="kpi"><div class="v">${sum.total}</div><div class="l">Sesiones</div></div>
        <div class="kpi"><div class="v">${sum.avgConc}</div><div class="l">Concentración prom.</div></div>
        <div class="kpi"><div class="v">${sum.totalMin}</div><div class="l">Min totales</div></div>
        <div class="kpi"><div class="v">${sum.avgDur}</div><div class="l">Min prom./sesión</div></div>
      </div>

      <div class="grid cols-2" style="margin-top:18px;">
        <div class="card">
          <h2>Distribución Likert</h2>
          ${[1,2,3,4,5].map(v => {
            const c = dist[v] || 0;
            const pct = total ? (c / total) * 100 : 0;
            return `<div>
              <div style="display:flex;justify-content:space-between;font-size:13px;">
                <span>${v} — ${esc(Sessions.LIKERT[v-1].label)}</span>
                <span class="muted">${c} (${pct.toFixed(0)}%)</span>
              </div>
              <div class="bar"><span style="width:${pct}%"></span></div>
            </div>`;
          }).join('')}
        </div>

        <div class="card">
          <h2>Por franja horaria</h2>
          ${renderBar(buckets, 'bucket')}
        </div>

        <div class="card">
          <h2>Por materia</h2>
          ${renderBar(subs, 'subject')}
        </div>

        <div class="card">
          <h2>Por actividad previa</h2>
          ${renderBar(acts, 'activity')}
        </div>
      </div>`;
  }

  function wireStats() {
    root().querySelectorAll('[data-go]').forEach(b => b.addEventListener('click', (e) => { e.preventDefault(); App.go(b.dataset.go); }));
  }

  // ---- Pantalla 8: Recomendaciones ----
  function screenRecommend() {
    const email = Storage.get().currentEmail;
    const sessions = Sessions.listFor(email);
    const tips = Recommend.build(sessions);
    return `
      <h1>Recomendaciones personalizadas</h1>
      <p class="muted">Basadas en tus ${sessions.length} sesion${sessions.length === 1 ? '' : 'es'} registrada${sessions.length === 1 ? '' : 's'}.</p>
      <div style="margin-top:14px;">
        ${tips.map(t => `<div class="alert ${t.type}">${esc(t.text)}</div>`).join('')}
      </div>`;
  }

  return {
    flash,
    screens: {
      welcome: { render: screenWelcome, wire: wireWelcome },
      institution: { render: screenInstitution, wire: wireInstitution },
      dashboard: { render: screenDashboard, wire: wireDashboard },
      'new-session': { render: screenNewSession, wire: wireNewSession },
      subjects: { render: screenSubjects, wire: wireSubjects },
      history: { render: () => screenHistory(App._historyFilters || {}), wire: wireHistory },
      stats: { render: screenStats, wire: wireStats },
      recommend: { render: screenRecommend, wire: () => {} }
    }
  };
})();
