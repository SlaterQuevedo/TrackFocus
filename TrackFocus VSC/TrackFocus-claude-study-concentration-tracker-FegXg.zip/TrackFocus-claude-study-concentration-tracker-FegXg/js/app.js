// Router minimalista + bootstrap.
const App = (() => {
  const PUBLIC_ROUTES = ['welcome', 'institution'];
  let current = null;

  function go(route) {
    const s = Storage.get();
    // Gating: requiere usuario y luego institución.
    if (!s.currentEmail) route = 'welcome';
    else if (!s.students[s.currentEmail]?.institutionType && route !== 'institution') route = 'institution';

    current = route;
    const screen = UI.screens[route];
    if (!screen) {
      document.getElementById('app').innerHTML = `<div class="alert error">Pantalla desconocida: ${route}</div>`;
      return;
    }
    document.getElementById('app').innerHTML = screen.render();
    screen.wire();
    updateChrome();
    window.scrollTo({ top: 0, behavior: 'instant' });
  }

  function updateChrome() {
    const s = Storage.get();
    const nav = document.getElementById('topnav');
    const userbox = document.getElementById('userbox');
    const isPublic = PUBLIC_ROUTES.includes(current);

    if (isPublic) {
      nav.classList.add('hidden');
      userbox.classList.add('hidden');
    } else {
      nav.classList.remove('hidden');
      userbox.classList.remove('hidden');
      const student = s.students[s.currentEmail];
      document.getElementById('userLabel').textContent = `${student.name} · ${student.email}`;
      nav.querySelectorAll('button').forEach(b => b.classList.toggle('active', b.dataset.route === current));
    }
  }

  function bindGlobal() {
    document.getElementById('topnav').addEventListener('click', (e) => {
      const r = e.target.closest('button')?.dataset.route;
      if (r) go(r);
    });
    document.getElementById('logoutBtn').addEventListener('click', () => {
      Storage.set(s => { s.currentEmail = null; });
      go('welcome');
    });
  }

  function start() {
    bindGlobal();
    const s = Storage.get();
    if (!s.currentEmail) go('welcome');
    else if (!s.students[s.currentEmail].institutionType) go('institution');
    else go('dashboard');
  }

  return { go, start, _historyFilters: {} };
})();

window.addEventListener('DOMContentLoaded', App.start);
